AC_1_2 == > Unprotected admin functionalities + Unprotected admin functionality with
unpredictable


AC_3 ==> User role
controlled by
request
parameter


AC_4 ==> User role can be
modified in user
profile


AC_5 ==>
User ID
controlled by
request
parameter


AC_6 ==> 
Method-based
access control You 
change the request to get instead of post, and
add the username and action to UPGRADE



infomration diclouser 

1- Information
disclosure in
error messages

2- Information
disclosure on
debug page

3- Information
disclosure via
backup files
